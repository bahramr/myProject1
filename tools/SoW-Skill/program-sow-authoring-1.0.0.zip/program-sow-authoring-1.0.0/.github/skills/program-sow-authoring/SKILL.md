---
name: program-sow-authoring
description: 'Generate or validate a governance-traceable Statement of Work from Ring/RPI, CCK, or generic consulting artifacts using an approved K360 template; use for SOW drafting, validation, traceability appendices, and reusable SOW delivery workflows - Brought to you by microsoft/hve-core'
---

# Program SOW Authoring

## Overview

Generate or validate a Statement of Work (SOW) from existing engagement
evidence. The skill discovers source artifacts, preserves approved template
language, builds grounding-to-delivery traceability, validates the result, and
creates revision-safe outputs.

The workflow supports Ring/RPI workspaces, Consulting Copilot Kit (CCK)
pipelines, and repositories with custom layouts. Workspace governance updates
are optional and disabled by default.

## Prerequisites

* An approved K360 SOW template that matches the engagement or deal type
* Source artifacts for scope, delivery, schedule, staffing, assumptions, risks,
  and commercial terms
* A SOW authoring agent or equivalent document tooling capable of preserving
  the supplied DOCX template
* Permission to use the supplied template

> [!IMPORTANT]
> Do not bundle or redistribute official K360 templates unless the distributor
> has confirmed redistribution rights. Treat the template as a user-supplied
> prerequisite.

## Quick Start

1. Determine whether the request is `generate` or `validate`.
2. Resolve the parameters from the request and available workspace evidence.
3. Detect the artifact profile using
   [artifact discovery](references/artifact-discovery.md).
4. Confirm the template and output revision before changing files.
5. Follow [authoring and validation](references/authoring-validation.md).
6. Build the appendix using
   [traceability rules](references/traceability.md).
7. Apply [governance adapters](references/governance-adapters.md) only when
   requested or required by active workspace instructions.
8. Report outputs, validation findings, traceability gaps, and pending human
   decisions.

## Parameters Reference

| Parameter | Required | Default | Description |
|---|---:|---|---|
| `mode` | No | `generate` | `generate` or `validate` |
| `customerName` | Generate | None | Customer name for headers and filenames |
| `engagementTitle` | Generate | None | Engagement or program title |
| `templatePath` | Generate | Auto-discover | Approved source DOCX template |
| `templateVariant` | No | Auto-detect | Template variant or mapped deal type |
| `artifactProfile` | No | `auto` | `ring-rpi`, `cck`, or `generic` |
| `sourcePaths` | Generic | None | Explicit source files or directories |
| `existingSowPath` | Validate | None | SOW to validate |
| `outputDirectory` | No | `03. Output/SOW` | Final output directory |
| `workingDirectory` | No | `SOW-Author-working` | Draft and report directory |
| `outputRevision` | No | Next available | Revision suffix or label |
| `updateGovernanceArtifacts` | No | `false` | Update RTM, journal, and decision log |
| `generateWbs` | No | `false` | Produce a standalone WBS export |

## Required Protocol

### Phase 1: Intake and safety

1. Inspect active workspace instructions before authoring.
2. Resolve values already present in source artifacts.
3. Ask for each missing decision separately. Do not infer contract type,
   template variant, commercial terms, approval authority, or decision-point
   numbers when multiple answers remain reasonable.
4. Verify that the source template exists and that the output path will not
   overwrite an existing revision.
5. Stop generation when no approved template is available. Validation mode may
   continue when an existing SOW is supplied.

### Phase 2: Evidence discovery

1. Detect the artifact profile.
2. Build an evidence manifest that records source path, purpose, authority,
   revision or date, and selected or rejected status.
3. Prefer explicitly selected plans over alternatives. Never treat proposals
   or superseded artifacts as approved scope.
4. Record missing expected evidence as a gap. Do not invent substitute facts.

### Phase 3: Template authoring

1. Copy the approved template to a new revision-safe output path.
2. Preserve approved legal and template language unless the template
   instructions explicitly identify it as replaceable.
3. Populate project-specific fields only from evidence or confirmed user input.
4. Mark unresolved content as `[TO BE PROVIDED - reason]`.
5. Use a configured SOW authoring agent when available. Provide the complete
   evidence manifest, resolved parameters, template path, output path, and
   acceptance criteria in the delegation.
6. If the configured authoring resources cannot perform MCAPS validation,
   label the result as structural validation only. Do not return a
   success-shaped MCAPS result.

### Phase 4: Traceability and validation

1. Add the grounding-to-delivery appendix without deleting standard template
   appendices.
2. Validate that every approved requirement appears in the appendix.
3. Verify that every cited file and identifier resolves.
4. Run structural, terminology, deal-pattern, cross-reference, and template
   preservation checks.
5. Classify findings by severity and distinguish blocking defects from advisory
   improvements.

### Phase 5: Output and handoff

1. Save the working draft and validation report.
2. Save the populated DOCX with a `.docx` extension.
3. Apply governance updates only when `updateGovernanceArtifacts` is `true` or
   active workspace rules make them mandatory.
4. Present the source template, generated revision, draft, validation report,
   traceability gaps, and required human approvals.
5. Never state that the SOW is approved, legally sufficient, or ready for
   signature without the designated human approval.

## Output Contract

Generation mode produces:

* `SOW-Author-working/sow-draft.md`
* `SOW-Author-working/sow-validation-report.md`
* `SOW-Author-working/traceability-appendix.md`
* `03. Output/SOW/SOW-{Customer}-{Date}[-revN].docx`

Validation mode produces:

* `SOW-Author-working/sow-validation-report.md`
* A corrected revision only when the user requested remediation

Optional WBS generation produces:

* `SOW-Author-working/wbs-draft.md`
* `03. Output/SOW/WBS-{Customer}-{Date}[-revN].xlsx`

## Troubleshooting

| Condition | Required response |
|---|---|
| No approved template | Stop generation and request a template |
| Multiple plausible templates | Ask the user to select one |
| Conflicting source artifacts | Report the conflict and request authority |
| Missing commercial terms | Request only the unresolved commercial inputs |
| Missing traceability link | Insert a gap marker and report it |
| Existing output revision | Select the next revision; never overwrite |
| Authoring agent unavailable | Continue only within available validation scope and disclose the limitation |
| Track changes unsupported | Preserve a clean source copy and report the limitation before claiming tracked output |

## Attribution

Adapted from the Consulting Copilot Kit SOW authoring workflow and the
workspace-specific program SOW traceability prompt.

*Brought to you by microsoft/hve-core*
