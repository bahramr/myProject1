---
title: Program SOW Governance Adapters
description: Optional Ring and repository governance updates for reusable SOW authoring
---

## Activation

Apply these adapters only when `updateGovernanceArtifacts` is `true` or active
workspace instructions explicitly require them. The core skill remains usable
without Ring, journal, RTM, or decision-log files.

## Requirements traceability adapter

When a live requirements traceability matrix exists:

1. Add only links discovered and verified during SOW assembly.
2. Preserve the matrix's existing identifiers and schema.
3. Do not convert unresolved appendix gaps into verified RTM links.
4. Report proposed scope changes instead of silently adding them.

## Journal adapter

When the workspace requires event-sourced journaling:

1. Use the configured governance or journal tool first.
2. Use the workspace's documented fallback only when the preferred tool is
   unavailable.
3. Record intake, material reasoning, human decisions, validation outcome, and
   handoff.
4. Never record approval before the designated human provides it.

## Decision adapter

Record a decision only when the SOW assembly creates or confirms a significant
decision. Capture:

* Decision
* Policy
* Authority
* Accountability

Ask which human decision point applies before recording a decision-point
number. Never infer or auto-correct a decision-point number.

## Revision and approval adapter

Keep generated SOW status distinct from approval status:

* `Draft`: Generated but not fully reviewed
* `Validated`: Automated or agent checks passed within the stated scope
* `Approved`: Designated human authorities approved the revision
* `Executed`: Required parties signed or otherwise executed the agreement

Generation and validation never imply approval or execution.
