---
title: Program SOW Authoring and Validation
description: Template population, section ordering, and validation rules for program SOWs
---

## Template selection

Select the template from explicit user input, an authoritative engagement
record, or the selected delivery and staffing model. When different naming
systems are used, map the repository's deal type to the available template
variants and ask the user to confirm an ambiguous mapping.

Never replace an approved K360 template with a newly invented document
structure.

## Template preservation

Follow the instructions embedded in the supplied template. When the template
uses color-coded guidance:

* Preserve approved black legal language unless the template explicitly marks
  the field as editable
* Replace instructional or placeholder content only where directed
* Replace variable fields such as customer, date, and scope with verified values
* Append project-specific rows to protected tables rather than deleting
  approved rows
* Keep a pristine copy of the source template

If the document tooling cannot reliably interpret the template's colors or
revision semantics, stop and report the limitation.

## Section dependency order

Populate sections in this order:

1. Scope of Services
2. Deliverables and Acceptance Criteria
3. Timeline and Milestones
4. Roles and Responsibilities
5. Assumptions and Dependencies
6. Out of Scope
7. Commercial Terms
8. Change Management
9. Governance and Communication
10. Acceptance Process
11. Warranty and Support
12. Termination and Exit
13. Executive Summary

Write the Executive Summary last so it reflects the agreed scope, schedule,
commercial model, and constraints.

## Required validation

Run these checks against agent-added or changed content:

| Check | Blocking condition |
|---|---|
| Template integrity | Approved language or required section was removed |
| Structural completeness | Required section is missing or empty |
| Acceptance quality | Deliverable lacks measurable acceptance criteria |
| Terminology | Added language creates an unsupported obligation or guarantee |
| Deal-pattern alignment | Scope, payment, staffing, or acceptance conflicts with the contract model |
| Cross-reference integrity | Referenced section, deliverable, milestone, or appendix does not exist |
| Evidence integrity | Material claim has no source or confirmed user input |
| Traceability | Approved requirement is missing or points to unresolved evidence |
| Output integrity | Output overwrote a prior revision or lacks the `.docx` extension |

Use configured MCAPS references or the designated SOW authoring agent for a
formal MCAPS assessment. Without them, report only the checks actually
performed.

## Finding format

| ID | Severity | Section | Finding | Evidence | Required remediation |
|---|---|---|---|---|---|

Use `Critical`, `High`, `Medium`, or `Low`. A missing approved template,
modified protected language, unapproved commercial commitment, or unresolved
scope authority blocks completion.

## Human review

Generated content remains a draft until the designated commercial, legal,
delivery, and customer authorities complete their required review. Preserve
track changes when supported. Otherwise, provide a clean source copy and a
change summary without claiming that revision tracking is enabled.
