---
title: Program SOW Traceability
description: Grounding-to-delivery appendix schema and validation rules for program SOWs
---

## Required appendix

Add an appendix titled `Appendix - Grounding-to-Delivery Traceability`.

Use one row per approved requirement or scope item:

| Grounding Source | Requirement or Scope Item | Architecture Component | WBS Work Package | IMS Milestone | BOM Line Item | Build Cost | Operating Cost |
|---|---|---|---|---|---|---|---|

## Join rules

Join evidence using stable identifiers such as requirement IDs, work-package
IDs, milestone IDs, decision IDs, and BOM line IDs. Do not join solely on
similar wording when stable identifiers exist.

Resolve columns as follows:

| Column | Source |
|---|---|
| Grounding Source | Objective, research, transcript, or approved requirement source |
| Requirement or Scope Item | Approved requirements list or requirements traceability matrix |
| Architecture Component | Selected solution plan, architecture view, or ADR |
| WBS Work Package | Selected WBS and cost baseline |
| IMS Milestone | Selected IMS or integrated master schedule |
| BOM Line Item | Approved infrastructure or service BOM |
| Build Cost | Labor, implementation, and development token cost allocated to the work package |
| Operating Cost | Infrastructure, service, support, and operating token cost |

## Gap handling

Do not omit a requirement because one or more downstream links are absent.
Write `[GAP - not found in expected artifact]` in each unresolved cell and add a
traceability-gaps section below the table.

Each gap entry records:

* Requirement or scope identifier
* Missing link
* Expected source
* Impact on the SOW
* Required owner or decision

## Validation

The appendix passes only when:

1. Every approved requirement appears exactly once unless documented
   one-to-many decomposition is necessary.
2. Every source path and stable identifier resolves.
3. Selected WBS and IMS items are used instead of rejected alternatives.
4. Costs reconcile with their authoritative baselines.
5. No appendix row introduces scope absent from the approved evidence.

Report orphan requirements, orphan deliverables, duplicate mappings, missing
cost allocations, and stale source references as findings.
