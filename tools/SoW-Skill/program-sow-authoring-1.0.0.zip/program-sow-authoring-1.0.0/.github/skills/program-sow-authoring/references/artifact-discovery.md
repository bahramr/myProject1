---
title: Program SOW Artifact Discovery
description: Artifact profiles and evidence selection rules for reusable SOW authoring
---

## Profile detection

Evaluate profiles in this order when `artifactProfile` is `auto`:

1. Ring/RPI
2. CCK
3. Generic

Select a profile only when its authoritative anchor exists. If more than one
profile has an authoritative anchor and they identify different selected plans,
stop and ask which profile governs the SOW.

## Ring/RPI profile

Use this profile when `docs/Planning/requirements-traceability.md` or
`docs/Planning/ring-status.md` exists.

| Evidence category | Preferred locations |
|---|---|
| Original grounding | `docs/customer-docs/Objective/`, `docs/customer-docs/Research-docs/`, `docs/customer-docs/transcripts/` |
| Requirements | `docs/customer-docs/Objective/objective-summary.md`, `docs/Planning/requirements-traceability.md` |
| Decisions | `docs/Governance/decisions/decision-log.md`, `docs/Governance/decisions/decision-review-log.md` |
| Scope changes | `docs/Planning/scope-changes.md` |
| Risks and dependencies | `docs/Planning/risk-register.md`, `docs/Planning/dependency-matrix.md` |
| Selected solution | `docs/Planning/solutions/selected-solution-plan.md` |
| Architecture | `docs/Architecture/`, including static, dynamic, ADR, and traceability views |
| Selected WBS | Selected proposal under `docs/Planning/staffing/` plus `docs/Planning/cost-baseline.md` |
| Selected IMS | Selected schedule under `docs/Planning/schedule/` plus `docs/Planning/integrated-master-schedule.md` |
| Azure BOM and operating cost | `docs/Planning/azure-bom-opex-estimate.md` |
| Build and token cost | `docs/Planning/cost-baseline.md`, `docs/Planning/token-review-baseline.md` |
| Templates | `docs/K360-SoW-templates/` |

When an expected path is absent, search equivalent customer, architecture, and
planning folders before reporting a gap.

## CCK profile

Use this profile when `engagement-status.md`,
`Solution-Architect-working/solution-plan.md`, or
`MM-Solution-Architect-working/solution-plan.md` exists.

Read `engagement-status.md` first when present. Use its pipeline field to select
the AI or migration pipeline. Extract scope, delivery model, staffing,
timeline, assumptions, ROM or cost, and risks from the selected solution plan.

Treat a pipeline plan as selected only when the engagement status or another
authoritative decision artifact identifies it as current.

## Generic profile

Use this profile when explicit `sourcePaths` are supplied or neither structured
profile matches.

Classify supplied evidence into:

* Grounding and objectives
* Requirements and scope
* Architecture or solution approach
* Deliverables and acceptance criteria
* Work breakdown and staffing
* Schedule and milestones
* Risks, assumptions, and dependencies
* Commercial terms
* Cost to build and cost to operate

Report missing categories. Do not require Ring/RPI or CCK governance files.

## Evidence manifest

Record one row per source:

| Source | Category | Authority | Revision or date | Status | Notes |
|---|---|---|---|---|---|

Valid status values are `selected`, `supporting`, `superseded`, `rejected`, and
`unresolved`. Only `selected` and `supporting` evidence may define SOW content.
