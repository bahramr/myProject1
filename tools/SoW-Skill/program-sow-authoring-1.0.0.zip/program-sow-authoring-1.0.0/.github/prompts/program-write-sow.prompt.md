---
mode: agent
description: Generate or validate a governance-traceable Statement of Work from program artifacts and an approved K360 template
argument-hint: "[mode=generate|validate] [customerName=...] [engagementTitle=...] [templateVariant=...] [artifactProfile=auto|ring-rpi|cck|generic] [outputRevision=...]"
---

# Write Program SOW

Use the `program-sow-authoring` skill to generate or validate a Statement of
Work. The skill owns artifact discovery, template handling, traceability,
validation, output naming, and optional workspace-governance updates.

## Inputs

* `${input:mode:generate}`: `generate` to create a SOW or `validate` to review
  an existing SOW
* `${input:customerName}`: Customer name used in document headers and output
  filenames
* `${input:engagementTitle}`: Engagement or program title
* `${input:templateVariant}`: Template variant or deal type, when known
* `${input:artifactProfile:auto}`: `auto`, `ring-rpi`, `cck`, or `generic`
* `${input:outputRevision}`: Optional revision label; when omitted, select the
  next available revision without overwriting an existing file

Ask only for required information that cannot be recovered from available
artifacts. Do not claim MCAPS compliance unless the configured validation
resources support that assessment.

## User Request

{{input}}
