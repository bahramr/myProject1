#!/usr/bin/env pwsh
# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: MIT
#Requires -Version 7.0

<#
.SYNOPSIS
    Installs the Program SOW Authoring prompt and skill.
.DESCRIPTION
    Copies the bundled prompt and skill into a target Copilot workspace.
    Existing bundle-owned files are preserved unless Force is specified.
.PARAMETER TargetPath
    Root directory of the target workspace.
.PARAMETER Force
    Replaces existing files owned by this bundle.
.EXAMPLE
    ./install.ps1 -TargetPath 'C:\src\customer-workspace'
.EXAMPLE
    ./install.ps1 -TargetPath 'C:\src\customer-workspace' -Force
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [string]$TargetPath = (Get-Location).Path,

    [Parameter(Mandatory = $false)]
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

#region Functions
function Install-BundleFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$RelativePath,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$DestinationRoot,

        [Parameter(Mandatory = $true)]
        [bool]$AllowOverwrite
    )

    $SourcePath = Join-Path $PSScriptRoot $RelativePath
    $DestinationPath = Join-Path $DestinationRoot $RelativePath

    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
        throw "Bundle source file is missing: $RelativePath"
    }

    if ((Test-Path -LiteralPath $DestinationPath) -and -not $AllowOverwrite) {
        throw "Destination exists: $DestinationPath. Use -Force to replace it."
    }

    $DestinationDirectory = Split-Path -Parent $DestinationPath
    $null = New-Item -ItemType Directory -Path $DestinationDirectory -Force
    Copy-Item -LiteralPath $SourcePath -Destination $DestinationPath -Force
}

function Test-BundleFile {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$RelativePath,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$DestinationRoot,

        [Parameter(Mandatory = $true)]
        [bool]$AllowOverwrite
    )

    $SourcePath = Join-Path $PSScriptRoot $RelativePath
    $DestinationPath = Join-Path $DestinationRoot $RelativePath

    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) {
        throw "Bundle source file is missing: $RelativePath"
    }

    if ((Test-Path -LiteralPath $DestinationPath) -and -not $AllowOverwrite) {
        throw "Destination exists: $DestinationPath. Use -Force to replace it."
    }
}
#endregion Functions

#region Main Execution
if ($MyInvocation.InvocationName -ne '.') {
    try {
        $ResolvedTarget = [System.IO.Path]::GetFullPath($TargetPath)
        $ManifestPath = Join-Path $PSScriptRoot 'manifest.json'

        if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
            throw "Bundle manifest is missing: $ManifestPath"
        }

        $Manifest = Get-Content -LiteralPath $ManifestPath -Raw |
            ConvertFrom-Json

        foreach ($RelativePath in $Manifest.files) {
            Test-BundleFile `
                -RelativePath $RelativePath `
                -DestinationRoot $ResolvedTarget `
                -AllowOverwrite $Force.IsPresent
        }

        foreach ($RelativePath in $Manifest.files) {
            Install-BundleFile `
                -RelativePath $RelativePath `
                -DestinationRoot $ResolvedTarget `
                -AllowOverwrite $Force.IsPresent
        }

        Write-Host (
            "Installed {0} {1} to {2}" -f
            $Manifest.name,
            $Manifest.version,
            $ResolvedTarget
        ) -ForegroundColor Green
        exit 0
    }
    catch {
        Write-Error -ErrorAction Continue (
            "Program SOW Authoring installation failed: {0}" -f
            $_.Exception.Message
        )
        exit 1
    }
}
#endregion Main Execution
