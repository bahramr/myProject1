#!/usr/bin/env bash
# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: MIT
#
# install.sh
# Installs the Program SOW Authoring prompt and skill.

set -euo pipefail

usage() {
  cat <<'EOF'
Usage: ./install.sh [--target PATH] [--force]

Options:
  --target PATH  Target workspace root. Defaults to the current directory.
  --force        Replace existing files owned by this bundle.
  --help, -h     Show this help message.
EOF
}

err() {
  printf 'ERROR: %s\n' "$1" >&2
  exit 1
}

copy_bundle_file() {
  local relative_path="$1"
  local source_path="${SCRIPT_DIR}/${relative_path}"
  local destination_path="${TARGET_PATH}/${relative_path}"

  [[ -f "${source_path}" ]] ||
    err "Bundle source file is missing: ${relative_path}"

  if [[ -e "${destination_path}" && "${FORCE}" != "true" ]]; then
    err "Destination exists: ${destination_path}. Use --force to replace it."
  fi

  mkdir -p "$(dirname "${destination_path}")"
  cp "${source_path}" "${destination_path}"
}

validate_bundle_file() {
  local relative_path="$1"
  local source_path="${SCRIPT_DIR}/${relative_path}"
  local destination_path="${TARGET_PATH}/${relative_path}"

  [[ -f "${source_path}" ]] ||
    err "Bundle source file is missing: ${relative_path}"

  if [[ -e "${destination_path}" && "${FORCE}" != "true" ]]; then
    err "Destination exists: ${destination_path}. Use --force to replace it."
  fi
}

main() {
  SCRIPT_DIR="$(
    cd -- "$(dirname -- "${BASH_SOURCE[0]}")" >/dev/null 2>&1
    pwd
  )"
  TARGET_PATH="${PWD}"
  FORCE="false"

  while (( $# > 0 )); do
    case "$1" in
      --target)
        (( $# >= 2 )) || err "--target requires a path"
        TARGET_PATH="$2"
        shift 2
        ;;
      --force)
        FORCE="true"
        shift
        ;;
      --help|-h)
        usage
        exit 0
        ;;
      *)
        usage >&2
        err "Unknown argument: $1"
        ;;
    esac
  done

  TARGET_PATH="$(cd -- "${TARGET_PATH}" && pwd)"

  local -a files=(
    ".github/prompts/program-write-sow.prompt.md"
    ".github/skills/program-sow-authoring/SKILL.md"
    ".github/skills/program-sow-authoring/references/artifact-discovery.md"
    ".github/skills/program-sow-authoring/references/authoring-validation.md"
    ".github/skills/program-sow-authoring/references/governance-adapters.md"
    ".github/skills/program-sow-authoring/references/traceability.md"
  )

  local relative_path
  for relative_path in "${files[@]}"; do
    validate_bundle_file "${relative_path}"
  done

  for relative_path in "${files[@]}"; do
    copy_bundle_file "${relative_path}"
  done

  printf 'Installed program-sow-authoring to %s\n' "${TARGET_PATH}"
}

main "$@"
