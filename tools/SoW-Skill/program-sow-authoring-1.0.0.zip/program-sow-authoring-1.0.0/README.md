---
title: Program SOW Authoring Bundle
description: Install the reusable Program SOW Authoring prompt and skill in a Copilot workspace
---

## Contents

This bundle installs:

* `.github/prompts/program-write-sow.prompt.md`
* `.github/skills/program-sow-authoring/SKILL.md`
* The skill's focused reference files

The bundle does not include a K360 template. Supply an approved template
separately and confirm that you have permission to use it.

## Install with PowerShell

From the extracted bundle directory:

```powershell
./install.ps1 -TargetPath 'C:\path\to\workspace'
```

To replace an existing installation:

```powershell
./install.ps1 -TargetPath 'C:\path\to\workspace' -Force
```

PowerShell 7 or later is required.

## Install with Bash

From the extracted bundle directory:

```bash
./install.sh --target /path/to/workspace
```

To replace an existing installation:

```bash
./install.sh --target /path/to/workspace --force
```

Bash 5 or later is recommended.

## Verify installation

Confirm these files exist in the target workspace:

```text
.github/prompts/program-write-sow.prompt.md
.github/skills/program-sow-authoring/SKILL.md
.github/skills/program-sow-authoring/references/artifact-discovery.md
.github/skills/program-sow-authoring/references/authoring-validation.md
.github/skills/program-sow-authoring/references/governance-adapters.md
.github/skills/program-sow-authoring/references/traceability.md
```

Restart or reload the Copilot-enabled editor after installation if the new
prompt or skill is not discovered immediately.

## Update the bundle

Install a newer version with `-Force` or `--force`. The installer replaces the
files owned by this bundle. It does not modify other prompts, skills, or
workspace files.

## License and attribution

The bundle contains reusable workflow instructions adapted from the Consulting
Copilot Kit SOW authoring workflow and the program traceability workflow.

*Brought to you by microsoft/hve-core*
